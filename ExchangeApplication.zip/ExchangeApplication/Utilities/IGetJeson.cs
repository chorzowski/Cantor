﻿using ExchangeApplication.Models;

namespace ExchangeApplication.Utilities
{
    public interface IGetJeson
    {
        AccountResponse GetJson();
    }
}